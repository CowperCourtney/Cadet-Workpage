<div class="report-footer">
    <div class="row">
        <div class="col-xs-6 left">
            <strong>Copyright &copy; {{date('Y')}} <i>{{$instituteName}}</i> All rights reserved.</strong>
        </div>
        <div class="col-xs-6 right">
            <strong>CloudSchool v{{$majorVersion}}.{{$minorVersion}}.{{$patchVersion}}-{{$suffixVersion}} || Developed by <i>{{$maintainer}}</i></strong>
        </div>
    </div>
</div>